#import <Preferences/PSListController.h>

@interface ATLApplicationListSubcontroller : PSListController
@property (nonatomic) NSString* applicationID;
@end